local mod = RegisterMod("ShaderMod", 1)
function mod:GetShaderParams(shaderName)
	if shaderName == 'RandomColors' then
        local playerPos = Isaac.GetPlayer(0).Position
        local params = { 
            PlayerPos = {   playerPos.X / 100.0,
                            playerPos.Y / 100.0 },
                            Time = Isaac.GetFrameCount()
            }
        return params;
    end
end
mod:AddCallback(ModCallbacks.MC_GET_SHADER_PARAMS, mod.GetShaderParams)