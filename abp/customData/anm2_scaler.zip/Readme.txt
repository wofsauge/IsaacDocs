A small tool made by Wofsauge that scales any ".anm2" file with a given factor

How to use:
1. Put the ".anm2" files you want to scale into a folder
2. Put the "Scaling helper.exe" file in the same folder
3. execute the .exe file
4. input a Scaling factor (example: 2 will scale a 32x32px based animation to 64x64px)
5. Finished

INFO: You need to manually scale your spritesheets with the same factor!