import os;
import os.path;
import sys;
from PIL import Image;

def PasteImagesHorizontally(image1, image2):
	images = map(Image.open, [image1, image2]);
	widths, heights = zip(*(i.size for i in images))
	total_width = sum(widths)
	max_height = max(heights)
	new_im = Image.new("RGBA", (total_width, max_height))
	x_offset = 0
	images = map(Image.open, [image1, image2])
	for im in images:
		new_im.paste(im, (x_offset, 0))
		x_offset += im.size[0]
	new_im.save(image1)
	
print("Input 'mergeall' to merge all the mods\nor give a list of mods to merge like this 'mod1,mod2,mod3' \n(use the name of the mod folder)\ncheck mergeoptions.txt for more options");

while (True):
	if not os.path.isfile("mergeoptions.txt"):
		file = open("mergeoptions.txt", "w")
		file.write("disable-mods-after-merge: true\nonly-merge-enabled-mods: false")
		file.close()
	user_input = input()
	directories = []
	xmltypes = ["achievements", "babies", "backdrops", "bosscolors", "bosses", "challenges", "costumes", "curses", "cutscenes", "entities", "giantbook", "ItemPools", "items", "minibosses", "music", "nightmares", "players", "pocketitems", "preloads", "sounds", "stages", "translations"];
	amountplayermods = 0;
	mainluafiles = 0;
	numberluamods = 1;
	mergedmodsnames = ""
	charactermenuxcrop = 0
	deathportraitxcrop = 0
	
	file = open("mergeoptions.txt", "r")
	options = file.read().replace("disable-mods-after-merge:", "").replace("only-merge-enabled-mods:", "").replace(" ","").split("\n")
	file.close()
	
	if user_input == "mergeall":	
		i = -1
		for filename in os.listdir(os.getcwd()):
			if os.path.isdir(filename) and filename != "Mergedmods":
				if not os.path.isfile(filename+"/disable.it") or options[1] != "true":
					directories.append(filename+"/")
					if options[0] == "true":
						file = open(filename+"/disable.it", "w")
						file.close()
		metadatanames = []
		i = -1
		for directory in directories:
			i += 1
			file = open(directory+"/metadata.xml", "r", errors = "ignore")
			name = file.read().split("<name>")[1].split("</name>")[0]+"%"+str(i)
			file.close()
			metadatanames.append(name)
		metadatanames.sort(key = str.lower)
		sorteddirectories = []
		for metadataname in metadatanames:
			sorteddirectories.append(directories[int(metadataname.split("%")[1])])
			mergedmodsnames += ", "+metadataname.split("%")[0];
		directories = sorteddirectories
		apimods = []
		nonapimods = []
		for filename in directories:
			if filename.find("api") != -1:
				apimods.append(filename)
			else:
				nonapimods.append(filename)
		directories = apimods + nonapimods
	elif user_input.find(",") != -1:
		for filename in user_input.split(","):
			if os.path.isdir(filename):
				directories.append(filename+"/");
	else:
		break;
		
	if not os.path.exists("Mergedmods"):
		os.makedirs("Mergedmods");
		
	mergedmodsnames = mergedmodsnames.replace(", ", "", 1)
		
	file = open("Mergedmods/main.lua", "w")
	file.write('_G.MergedModdata = RegisterMod("MergedMod", 1)\n\nlocal json = require("json")\n\nMergedModdata.Load = Isaac.LoadModData\nMergedModdata.Has = Isaac.HasModData\n\nMergedModdata.Save = Isaac.SaveModDataif MergedModdata.Has(MergedModdata) then\n	local loadeddata = MergedModdata.Load(MergedModdata)\n	MergedModdata.Data = json.decode(loadeddata)\nelse MergedModdata.Data = {} end\n\nlocal OldRegisterMod = RegisterMod\nfunction RegisterMod(modname, version)\n	tblref = OldRegisterMod(modname, version)\n	tblref.mergedmoddataid = #MergedModdata.Data+1\n	MergedModdata.Data[tblref.mergedmoddataid] = ""\n	return tblref\nend\n\nfunction Isaac.SaveModData(tblref, data)\n	MergedModdata.Data[tblref.mergedmoddataid] = data\n	MergedModdata.Save(MergedModdata, json.encode(MergedModdata.Data))\nend\n\nfunction Isaac.LoadModData(tblref)\n	return MergedModdata.Data[tblref.mergedmoddataid]\nend\n\nfunction Isaac.HasModData(tblref)\n	if MergedModdata.Data[tblref.mergedmoddataid] and MergedModdata.Data[tblref.mergedmoddataid] ~= "" then\n		return true\n	else return false end\nend\n\nfunction Isaac.RemoveModData(tblref)\n	MergedModdata.Data[tblref.mergedmoddataid] = ""\nend')
	file.close()
	
	i = 0;
	while (i < len(directories)):
		for filename in os.listdir(directories[i]):
			mergedmoddir = directories[i].replace(directories[i].split("/")[0], "Mergedmods", 1);
			if os.path.isdir(directories[i]+filename):
				directories.append(directories[i]+filename+"/")
				if not os.path.exists(mergedmoddir+filename):
					os.makedirs(mergedmoddir+filename);
			elif filename == "main.lua":
				file = open(directories[i]+filename, "r", errors = "ignore");
				content1 = file.read();
				file.close();
				if mainluafiles != 0:
					filename = filename.replace(".lua", str(mainluafiles)+".lua");
				content2 = "";
				if os.path.isfile(mergedmoddir+filename):
					print("merging "+mergedmoddir+filename);
					file = open(mergedmoddir+filename, "r");
					content2 = file.read();
					file.close();
				else:
					print("setting up "+mergedmoddir+filename);
				if content2 != "":
					mainluafiles += 1;
					file = open(mergedmoddir+filename, "a");
					file.write('\n\nrequire("main'+str(mainluafiles)+'.lua")');
					file.close();
					if filename != "main.lua":
						filename = filename.replace(str(mainluafiles-1)+".lua", str(mainluafiles)+".lua");
					else:
						filename = "main1.lua";
				file = open(mergedmoddir+filename, "a");
				file.write(content1+"\n");
				file.close();
			elif filename.find(".xml") != -1 and directories[i].find("content") != -1:
				if os.path.isfile(mergedmoddir+filename):
					print("merging "+mergedmoddir+filename);
				else:
					print("setting up "+mergedmoddir+filename);
				file = open(directories[i]+filename, "r");
				content1 = file.read();
				file.close();
				content1 = content1.replace(" = ", "=");
				if filename == "players.xml":
					root = content1.split('"')[1];
					content1 = content1.replace(root, "", 1)
					portraitroot = content1.split('"')[3];
					content1 = content1.replace(portraitroot, "", 1)
					nameimageroot = content1.split('"')[5];
					content1 = content1.replace(nameimageroot, "", 1)
					bigportraitroot = content1.split('"')[7];
					content1 = content1.replace(bigportraitroot, "", 1)
					content1 = content1.replace('skin="', 'skin="'+root);
					content1 = content1.replace('portrait="', 'portrait="'+portraitroot);
					content1 = content1.replace('nameimage="', 'nameimage="'+nameimageroot);
					content1 = content1.replace('bigportrait="', 'bigportrait="'+bigportraitroot);
				elif filename == "costumes2.xml" or filename == "entities2.xml":
					root = content1.split('"')[1];
					content1 = content1.replace(root, "", 1)
					content1 = content1.replace('anm2path="', 'anm2path="'+root);
				elif filename == "music.xml" or filename == "sounds.xml":
					root = content1.split('"')[1];
					content1 = content1.replace(root, "", 1)
					content1 = content1.replace('intro="', 'intro="'+root);
					content1 = content1.replace('path="', 'path="'+root);
					content1 = content1.replace('layerintro="', 'layerintro="'+root);
					content1 = content1.replace('layer="', 'layer="'+root);
				multiline = False
				for s in xmltypes:
					for line in content1.split("\n"):
						if line.find("<"+s) != -1 and os.path.isfile(mergedmoddir+filename) or multiline or line.find("<?xml") != -1 and os.path.isfile(mergedmoddir+filename):
							if line.find(">") == -1:
								multiline = True
							else:
								multiline = False
							content1 = content1.replace("\n"+line, "")
							content1 = content1.replace(line, "")
				content2 = "";
				if os.path.isfile(mergedmoddir+filename):
					file = open(mergedmoddir+filename, "r");
					content2 = file.read();
					file.close();
				file = open(mergedmoddir+filename, "w");
				for s in xmltypes:
					for line in content2.split("\n"):
						if line.find("</"+s) != -1:
							content2 = content2.replace("\n"+line, "")
							content2 = content2.replace(line, "")
				file.write(content2+content1);
				file.close();
			elif filename.find(".anm2") != -1 and directories[i].find("content") != -1:
				filename = filename.lower();
				if os.path.isfile(mergedmoddir+filename):
					print("merging "+mergedmoddir+filename);
				else:
					print("setting up "+mergedmoddir+filename);
				file = open(directories[i]+filename, "r");
				content1 = file.read();
				content1 = content1.replace("	", "");
				file.close();
				if not os.path.isfile(mergedmoddir+filename):
					file = open(mergedmoddir+filename, "w");
					file.write(content1);
					file.close();
				else:
					file = open(mergedmoddir+filename, "r");
					content2 = file.read()
					file.close()
					file = open(mergedmoddir+filename, "w");
					content2 = content2.replace("	", "");
					
					if filename == "charactermenu.anm2":
						amountplayermods += 1;
						img = Image.open(directories[i]+"charactermenu.png")
						charactermenuxcrop += img.size[0]
						for line in content1.split("\n"):
							if line.find("<Frame ") != -1:
								startxcrop = line.split('"')[9]
								content3 = line.replace('XCrop="'+startxcrop, 'XCrop="'+str(int(startxcrop)+charactermenuxcrop), 1)
								content1 = content1.replace(line, content3, 1)
						players = ""
						isplayer = False
						for line in content1.split("\n"):
							if line.find("</Animations") != -1:
								break;
							if isplayer:
								players += "\n"+line;
							if line.find("<Animations") != -1:
								isplayer = True;
						content2 = content2.replace("</Animations>", players+"\n</Animations>");
					elif filename == "characterportraits.anm2":
						for line in content1.split("\n"):
							if line.find("<Frame ") != -1:
								startxcrop = line.split('"')[9]
								content3 = line.replace('XCrop="'+startxcrop, 'XCrop="'+str(int(startxcrop)+charactermenuxcrop), 1)
								content1 = content1.replace(line, content3, 1)
						players = ""
						isplayer = False
						for line in content1.split("\n"):
							if line.find("</Animations") != -1:
								break;
							if isplayer:
								players += "\n"+line;
							if line.find("<Animations") != -1:
								isplayer = True;
						content2 = content2.replace("</Animations>", players+"\n</Animations>");
					elif filename == "death screen.anm2":
						if os.path.isfile(directories[i]+"death portraits.png"):
							img = Image.open(directories[i]+"death portraits.png")
						else:
							img = Image.open(directories[i]+"deathportraits.png")
						deathportraitxcrop += img.size[0]
						for line in content1.split("\n"):
							if line.find("<Frame ") != -1:
								startxcrop = line.split('"')[9]
								content3 = line.replace('XCrop="'+startxcrop, 'XCrop="'+str(int(startxcrop)+deathportraitxcrop), 1)
								content1 = content1.replace(line, content3, 1)
						players = ""
						isplayer = False
						for line in content1.split("\n"):
							if line.find("</Animations") != -1:
								break;
							if isplayer:
								players += "\n"+line;
							if line.find("<Animations") != -1:
								isplayer = True;
						content2 = content2.replace("</Animations>", players+"\n</Animations>");
					file.write(content2);
					file.close()
			elif filename.find(".lua") != -1 or filename.find(".xml") != -1 and filename != "metadata.xml" or filename.find(".anm2") != -1:
				if os.path.isfile(mergedmoddir+filename):
					print("replaced "+mergedmoddir+filename);
				else:
					print("created "+mergedmoddir+filename);
				file = open(directories[i]+filename, "r");
				content = file.read();
				file.close();
				file = open(mergedmoddir+filename, "w");
				file.write(content);
				file.close();
			elif filename.find(".png") != -1 or filename.find(".jpg") != -1 or filename.find(".stb") != -1 or filename.find(".wav") != -1 or filename.find(".ogg") != -1:
				if os.path.isfile(mergedmoddir+filename) and filename.find(".png") == -1 and filename.find(".jpg") == -1:
					print("replaced "+mergedmoddir+filename);
				elif not os.path.isfile(mergedmoddir+filename):
					print("created "+mergedmoddir+filename);
				file = open(directories[i]+filename, "rb");
				content = file.read();
				file.close();
				if filename.lower() == "charactermenu.png" and os.path.isfile(mergedmoddir+filename):
					PasteImagesHorizontally(mergedmoddir+filename.lower(), directories[i]+filename)
				elif (filename.lower() == "death portraits.png" or filename.lower() == "deathportraits.png") and os.path.isfile(mergedmoddir+filename):
					PasteImagesHorizontally(mergedmoddir+"death portraits.png", directories[i]+filename)
				elif filename.find(".png") == -1 and filename.find(".jpg") == -1 or not os.path.isfile(mergedmoddir+filename):
					file = open(mergedmoddir+filename, "wb");
					file.write(content);
					file.close();
		i += 1;
	
	file = open("Mergedmods/modnames.txt", "w")
	file.write(mergedmodsnames)
	file.close()
	print("created Mergedmods/modnames.txt")
	
	print("")
	print("Merge Complete")
	print("These mods are merged: "+mergedmodsnames)
	
