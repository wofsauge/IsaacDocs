﻿using System;
using System.IO;
using System.Linq;
using System.Xml.Linq;
using static System.Net.Mime.MediaTypeNames;

namespace ConsoleApplication1
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            Console.WriteLine("Please type in a scaling factor (example:  4 ): ");
            int scalefactor = Int32.Parse(Console.ReadLine());

            foreach (string filee in Directory.GetFiles(Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location)))
            {
                if (Path.GetExtension(filee) != ".anm2")
                {
                    continue;
                }

                XDocument xmlFile = XDocument.Load(filee);

                var frames = from c in xmlFile.Elements("AnimatedActor").Elements("Animations").Elements("Animation").Elements("LayerAnimations").Elements("LayerAnimation").Elements("Frame")
                            select c;
                foreach (XElement frame in frames)
                {
                    frame.Attribute("XPivot").Value = "" + scalefactor * Int32.Parse(frame.Attribute("XPivot").Value.Split('.')[0]);
                    frame.Attribute("YPivot").Value = "" + scalefactor * Int32.Parse(frame.Attribute("YPivot").Value.Split('.')[0]);
                    frame.Attribute("Width").Value = "" + scalefactor * Int32.Parse(frame.Attribute("Width").Value.Split('.')[0]);
                    frame.Attribute("Height").Value = "" + scalefactor * Int32.Parse(frame.Attribute("Height").Value.Split('.')[0]);
                    frame.Attribute("XScale").Value = "" + Int32.Parse(frame.Attribute("XScale").Value.Split('.')[0]) / scalefactor;
                    frame.Attribute("YScale").Value = "" + Int32.Parse(frame.Attribute("YScale").Value.Split('.')[0]) / scalefactor;
                    frame.Attribute("XCrop").Value = "" + scalefactor * Int32.Parse(frame.Attribute("XCrop").Value.Split('.')[0]);
                    frame.Attribute("YCrop").Value = "" + scalefactor * Int32.Parse(frame.Attribute("YCrop").Value.Split('.')[0]);
                }
                var query2 = from c in xmlFile.Elements("AnimatedActor").Elements("Animations").Elements("Animation").Elements("NullAnimations").Elements("NullAnimation").Elements("Frame")
                            select c;
                foreach (XElement book in query2)
                {
                    book.Attribute("XPosition").Value = "" +  Int32.Parse(book.Attribute("XPosition").Value.Split('.')[0])/ scalefactor;
                    book.Attribute("YPosition").Value = "" +  Int32.Parse(book.Attribute("YPosition").Value.Split('.')[0])/ scalefactor;
                    book.Attribute("XScale").Value = "" + Int32.Parse(book.Attribute("XScale").Value.Split('.')[0]) / scalefactor;
                    book.Attribute("YScale").Value = "" + Int32.Parse(book.Attribute("YScale").Value.Split('.')[0]) / scalefactor;
                }
                xmlFile.Save(filee);
            }
        }
    }
}