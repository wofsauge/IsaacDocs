local mod = RegisterMod("Shader example", 1)

function mod:GetShaderParams(shaderName)
    local params = { 
        PlayerPos = { Isaac.GetPlayer(0).Position.X / 100.0,
                   Isaac.GetPlayer(0).Position.Y / 100.0 },
                    Time = Isaac.GetFrameCount()
        }
    return params;
end
mod:AddCallback(ModCallbacks.MC_GET_SHADER_PARAMS, mod.GetShaderParams)