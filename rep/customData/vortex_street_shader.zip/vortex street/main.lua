local mod = RegisterMod("Vortex Street", 1)

function mod:GetShaderParams(shaderName)
	if shaderName == 'VortexStreet' then
		local params = { 
			Enabled = 1,
			Time = Isaac.GetFrameCount()
			}
		return params;
	end
end
mod:AddCallback(ModCallbacks.MC_GET_SHADER_PARAMS, mod.GetShaderParams)